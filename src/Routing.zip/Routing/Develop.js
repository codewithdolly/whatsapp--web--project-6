import React from 'react'
import { useParams} from 'react-router'

const Develop = () => {
    // let { topicId } = useParams();

    return (
        <div>
            {/* <p>: {topicId}</p> */}
            <p>Hello there!</p>

        </div>

        
    )
}

export default Develop
