import React from 'react'

const MobileApp = () => {
    return (
        <div>
            This is App.
        </div>
    )
}

export default MobileApp
